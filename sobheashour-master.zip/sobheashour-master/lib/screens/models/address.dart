class Address {
  final String name;
  bool checked;

  Address({
    required this.name,
    this.checked = false,
  });
}
