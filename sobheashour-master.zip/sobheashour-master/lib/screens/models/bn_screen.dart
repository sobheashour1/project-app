import 'package:flutter/material.dart';

class BnScreen {
  final Widget widget;
  final String title;

  const BnScreen({
    required this.widget,
    required this.title,
  });
}
