package com.example.ui_app_vp8

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
